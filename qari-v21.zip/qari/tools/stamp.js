// يُشغَّل تلقائيًا عند كل نشر على Vercel (buildCommand) أو يدويًا: node tools/stamp.js
// يختم: تاريخ النشر + رقم البناء (commit) في version.json وsw.js وindex.html فيكتشف المتصفح الإصدار الجديد.
const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
const rd=f=>fs.readFileSync(path.join(root,f),'utf8'),wr=(f,s)=>fs.writeFileSync(path.join(root,f),s);
const vj=JSON.parse(rd('version.json'));
const sha=(process.env.VERCEL_GIT_COMMIT_SHA||process.env.GITHUB_SHA||'').slice(0,7)||('b'+Date.now().toString(36));
vj.build=sha;vj.date=new Date().toISOString();
if(process.env.VERCEL_GIT_COMMIT_MESSAGE&&vj.history&&vj.history[0]&&!vj.history[0].commit)vj.history[0].commit=process.env.VERCEL_GIT_COMMIT_MESSAGE.slice(0,120);
wr('version.json',JSON.stringify(vj,null,2));
let sw=rd('sw.js');sw=sw.replace(/const VERSION='[^']*',BUILD='[^']*'/,`const VERSION='${vj.version}',BUILD='${vj.build}'`);wr('sw.js',sw);
let ix=rd('index.html');ix=ix.replace(/window\.__APPV=\{v:'[^']*',b:'[^']*'\}/,`window.__APPV={v:'${vj.version}',b:'${vj.build}'}`);wr('index.html',ix);
console.log('stamped',vj.version,vj.build,vj.date);
