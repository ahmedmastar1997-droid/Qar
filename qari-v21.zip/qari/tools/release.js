// إصدار جديد: node tools/release.js 2.1.0 --added "ميزة 1|ميزة 2" --improved "تحسين" --fixed "إصلاح" [--migration] [--notes "نص قصير"] [--url "https://github.com/OWNER/REPO/releases/latest"]
const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
const a=process.argv.slice(2),ver=a[0];if(!/^\d+\.\d+\.\d+$/.test(ver||'')){console.log('الاستخدام: node tools/release.js 2.1.0 --added "..." --improved "..." --fixed "..."');process.exit(1)}
const opt=k=>{const i=a.indexOf('--'+k);return i>=0&&a[i+1]&&!a[i+1].startsWith('--')?a[i+1]:''},list=s=>s?s.split('|').map(x=>x.trim()).filter(Boolean):[];
const f=p=>path.join(root,p),vj=JSON.parse(fs.readFileSync(f('version.json'),'utf8'));
const entry={version:ver,date:new Date().toISOString().slice(0,10),added:list(opt('added')),improved:list(opt('improved')),fixed:list(opt('fixed'))};
vj.history=[entry,...(vj.history||[]).filter(h=>h.version!==ver)];vj.version=ver;vj.migration=a.includes('--migration');if(opt('notes'))vj.notes=opt('notes');if(opt('url'))vj.downloadUrl=opt('url');
fs.writeFileSync(f('version.json'),JSON.stringify(vj,null,2));
require('./stamp.js');console.log('تم تجهيز الإصدار',ver,'— ارفعه الآن إلى GitHub (git add . && git commit && git push)');
