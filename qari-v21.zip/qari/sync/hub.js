#!/usr/bin/env node
// وسيط المزامنة المحلي لتطبيق «قارئي الذكي» — يعمل على الحاسوب فقط (127.0.0.1) بلا إنترنت
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=+process.env.PORT||8765,DIR=path.resolve(process.env.QARI_HUB_DIR||path.join(__dirname,'QariSyncHub'));
fs.mkdirSync(path.join(DIR,'blobs'),{recursive:true});fs.mkdirSync(path.join(DIR,'rec'),{recursive:true});
const CF=path.join(DIR,'code.txt');
let CODE=process.env.QARI_CODE||(fs.existsSync(CF)?fs.readFileSync(CF,'utf8').trim():String(Math.floor(100000+Math.random()*900000)));fs.writeFileSync(CF,CODE);
const MF=path.join(DIR,'manifest.json');let M={ver:0,ents:{},hist:{}};try{M=Object.assign(M,JSON.parse(fs.readFileSync(MF,'utf8')))}catch(e){}
const saveM=()=>{fs.writeFileSync(MF+'.tmp',JSON.stringify(M));fs.renameSync(MF+'.tmp',MF)};
const log=s=>{const l=new Date().toISOString()+' '+s;try{fs.appendFileSync(path.join(DIR,'log.txt'),l+'\n')}catch(e){}console.log(l)};
const body=(req,max=64*1048576)=>new Promise((res,rej)=>{const a=[];let n=0;req.on('data',c=>{n+=c.length;if(n>max){rej(new Error('too large'));req.destroy();return}a.push(c)});req.on('end',()=>res(Buffer.concat(a)));req.on('error',rej)});
const send=(r,code,obj,type)=>{const b=Buffer.isBuffer(obj)?obj:Buffer.from(typeof obj=='string'?obj:JSON.stringify(obj));r.writeHead(code,{'Content-Type':type||(typeof obj=='string'?'text/plain; charset=utf-8':'application/json; charset=utf-8'),'Content-Length':b.length});r.end(b)};
const sha256File=f=>new Promise((res,rej)=>{const h=crypto.createHash('sha256'),s=fs.createReadStream(f);s.on('data',c=>h.update(c));s.on('end',()=>res(h.digest('hex')));s.on('error',rej)});
http.createServer(async(req,res)=>{
 const o=req.headers.origin||'*';
 res.setHeader('Access-Control-Allow-Origin',o);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Headers','x-qari-code,content-type,range');res.setHeader('Access-Control-Allow-Methods','GET,PUT,POST,OPTIONS');res.setHeader('Access-Control-Allow-Private-Network','true');res.setHeader('Access-Control-Max-Age','600');res.setHeader('Access-Control-Expose-Headers','content-range,content-length');
 if(req.method=='OPTIONS'){res.writeHead(204);return res.end()}
 const u=new URL(req.url,'http://x'),p=u.pathname,authed=req.headers['x-qari-code']===CODE;
 try{
  if(p=='/'&&req.method=='GET'){return send(res,200,`<meta charset=utf-8><body dir=rtl style="font-family:sans-serif;padding:20px"><h2>وسيط مزامنة قارئي الذكي</h2><p>الوسيط يعمل. رمز الاقتران: <b style="font-size:28px">${CODE}</b></p><p>عدد العناصر: ${Object.keys(M.ents).length} — الإصدار: ${M.ver}</p>`,'text/html; charset=utf-8')}
  if(p=='/ping')return send(res,200,{ok:true,ver:M.ver,auth:authed,app:'qari-hub',v:1});
  if(!authed)return send(res,401,{error:'bad code'});
  if(p=='/manifest'&&req.method=='GET')return send(res,200,{ver:M.ver,ents:M.ents});
  let m;
  if((m=p.match(/^\/rec\/([a-f0-9]{64})$/))){const f=path.join(DIR,'rec',m[1]+'.json');
   if(req.method=='PUT'){const b=await body(req,40*1048576);fs.writeFileSync(f,b);return send(res,200,{ok:true})}
   if(req.method=='GET'){if(!fs.existsSync(f))return send(res,404,{error:'no rec'});return send(res,200,fs.readFileSync(f),'application/json; charset=utf-8')}}
  if((m=p.match(/^\/blobstat\/([a-f0-9]{64})$/))){const f=path.join(DIR,'blobs',m[1]);return send(res,200,{have:fs.existsSync(f),part:fs.existsSync(f+'.part')?fs.statSync(f+'.part').size:0,size:fs.existsSync(f)?fs.statSync(f).size:0})}
  if((m=p.match(/^\/blob\/([a-f0-9]{64})\/commit$/))&&req.method=='POST'){const f=path.join(DIR,'blobs',m[1]),size=+u.searchParams.get('size');
   if(fs.existsSync(f))return send(res,200,{ok:true,already:true});if(!fs.existsSync(f+'.part'))return send(res,422,{error:'no part'});
   if(fs.statSync(f+'.part').size!==size){return send(res,422,{error:'size mismatch',part:fs.statSync(f+'.part').size})}
   const h=await sha256File(f+'.part');if(h!==m[1]){fs.unlinkSync(f+'.part');log('رفض ملف: بصمة غير مطابقة '+m[1].slice(0,8));return send(res,422,{error:'sha mismatch'})}
   fs.renameSync(f+'.part',f);return send(res,200,{ok:true})}
  if((m=p.match(/^\/blob\/([a-f0-9]{64})$/))){const f=path.join(DIR,'blobs',m[1]);
   if(req.method=='PUT'){const off=+u.searchParams.get('off')||0,b=await body(req,16*1048576),pf=f+'.part';
    if(fs.existsSync(f))return send(res,200,{ok:true,already:true,part:fs.statSync(f).size});
    const cur=fs.existsSync(pf)?fs.statSync(pf).size:0;if(off>cur)return send(res,409,{error:'gap',part:cur});
    const fd=fs.openSync(pf,off==0?'w':'r+');fs.writeSync(fd,b,0,b.length,off);fs.closeSync(fd);return send(res,200,{ok:true,part:fs.statSync(pf).size})}
   if(req.method=='GET'){if(!fs.existsSync(f))return send(res,404,{error:'no blob'});const st=fs.statSync(f),rg=req.headers.range&&req.headers.range.match(/bytes=(\d*)-(\d*)/);
    if(rg){const a=+rg[1]||0,b=rg[2]?Math.min(+rg[2],st.size-1):st.size-1;res.writeHead(206,{'Content-Type':'application/octet-stream','Content-Range':`bytes ${a}-${b}/${st.size}`,'Content-Length':b-a+1});return fs.createReadStream(f,{start:a,end:b}).pipe(res)}
    res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':st.size});return fs.createReadStream(f).pipe(res)}}
  if(p=='/commit'&&req.method=='POST'){const j=JSON.parse((await body(req,8*1048576)).toString('utf8')),conf=[];
   for(const e of j.ents||[]){const cur=M.ents[e.key];if((cur?cur.h:null)!==(e.base||null))conf.push({key:e.key,cur:cur||null});
    else if(e.k=='fl'&&!fs.existsSync(path.join(DIR,'blobs',e.h)))conf.push({key:e.key,error:'blob missing'});
    else if(e.k!='fl'&&!fs.existsSync(path.join(DIR,'rec',e.h+'.json')))conf.push({key:e.key,error:'rec missing'})}
   if(conf.length)return send(res,409,{conflicts:conf});
   for(const e of j.ents||[]){const cur=M.ents[e.key];if(cur){(M.hist[e.key]=M.hist[e.key]||[]).push({h:cur.h,m:cur.m,dev:cur.dev,t:Date.now()});if(M.hist[e.key].length>20)M.hist[e.key].shift()}
    M.ents[e.key]={h:e.h,m:e.m,k:e.k,rel:e.rel||'',fd:!!e.fd,nm:e.nm||'',size:e.size||0,dev:j.dev||'',t:Date.now()}}
   for(const x of j.hist||[]){(M.hist[x.key]=M.hist[x.key]||[]).push({h:x.h,m:x.m,dev:j.dev,t:Date.now(),kept:'overwritten'})}
   M.ver++;saveM();log(`مزامنة من ${j.dev||'?'}: ${(j.ents||[]).length} عنصر (إصدار ${M.ver})`);return send(res,200,{ok:true,ver:M.ver})}
  if(p=='/log')return send(res,200,fs.existsSync(path.join(DIR,'log.txt'))?fs.readFileSync(path.join(DIR,'log.txt'),'utf8').split('\n').slice(-150).join('\n'):'');
  send(res,404,{error:'not found'});
 }catch(e){log('خطأ: '+e.message);try{send(res,500,{error:e.message})}catch(x){}}
}).listen(PORT,'127.0.0.1',()=>{console.log(`\n=== وسيط مزامنة قارئي الذكي ===\nالعنوان: http://localhost:${PORT}\nرمز الاقتران (أدخله مرة واحدة في التطبيق): ${CODE}\nمجلد البيانات: ${DIR}\n`)});
