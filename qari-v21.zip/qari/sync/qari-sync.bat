@echo off
chcp 65001 >nul
title وسيط مزامنة قارئي الذكي
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [!] لم يتم العثور على Node.js. ثبّته من https://nodejs.org ثم أعد التشغيل.
  pause
  exit /b
)
set "ADB=adb"
where adb >nul 2>nul
if errorlevel 1 (
  if exist "%~dp0platform-tools\adb.exe" (
    set "ADB=%~dp0platform-tools\adb.exe"
  ) else (
    echo [!] لم يتم العثور على ADB. نزّل platform-tools من موقع Android وضع مجلدها بجانب هذا الملف باسم platform-tools.
    pause
    exit /b
  )
)
echo --- الأجهزة المتصلة ---
"%ADB%" devices
echo --- ربط الهاتف بالوسيط عبر USB ---
"%ADB%" reverse tcp:8765 tcp:8765
rem إعادة الربط تلقائيًا كل 5 ثوانٍ (إذا فُصل الكابل ثم وُصل)
start "ربط USB" /min cmd /c "for /l %%i in (0,0,1) do ("%ADB%" reverse tcp:8765 tcp:8765 >nul 2>&1 & timeout /t 5 >nul)"
start "" http://localhost:8765
node hub.js
pause
